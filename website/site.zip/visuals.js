window.ETRN_VISUALS = {
  "actions": {
    "A101": [
      "assets/orders_today.png"
    ],
    "A102": [
      {
        "src": "assets/komus_order_approve_01.png",
        "caption": "Откройте нужный заказ"
      },
      {
        "src": "assets/komus_order_approve_02.png",
        "caption": "Проверьте и заполните данные заказа"
      },
      {
        "src": "assets/komus_order_approve_03.png",
        "caption": "Нажмите «Утверждение»"
      },
      {
        "src": "assets/komus_order_approve_04.png",
        "caption": "Перейдите к подписанию"
      },
      {
        "src": "assets/komus_order_approve_05.png",
        "caption": "Подпишите документ"
      },
      {
        "src": "assets/komus_order_approve_06.png",
        "caption": "Дождитесь завершения подписи"
      },
      {
        "src": "assets/komus_order_approve_07.png",
        "caption": "Не закрывайте шторку вручную"
      },
      {
        "src": "assets/komus_order_approve_08.png",
        "caption": "Дождитесь зелёного подтверждения"
      },
      {
        "src": "assets/komus_order_approve_09.png",
        "caption": "Проверьте статус «Утвержден»"
      }
    ],
    "A103": [
      "assets/komus_title2_goskey_01.png",
      "assets/komus_title2_goskey_02.png",
      "assets/komus_title2_goskey_03.png",
      "assets/komus_title2_goskey_04.png",
      "assets/komus_title2_goskey_05.png",
      "assets/komus_title2_goskey_06.png",
      "assets/komus_title2_goskey_07.png",
      "assets/komus_title2_goskey_08.png"
    ],
    "A003": [
      "assets/reg_kep_ip.png"
    ],
    "A006": [
      "assets/reg_edo_settings.png",
      "assets/reg_edo_company_01.png",
      "assets/reg_edo_documents_toggle.png",
      "assets/reg_edo_pin.png",
      "assets/reg_mobile_settings.png",
      "assets/reg_mobile_signature_ok.png"
    ],
    "A303": [
      {
        "src": "assets/komus_title4_01.png",
        "caption": "Откройте «Выдача груза» и выберите результат"
      },
      {
        "src": "assets/komus_title4_02.png",
        "caption": "Перейдите к подписанию"
      },
      {
        "src": "assets/komus_title4_03.png",
        "caption": "Откройте подпись в Saby/Госключе"
      },
      {
        "src": "assets/komus_title4_04.png",
        "caption": "Подпишите документ"
      },
      {
        "src": "assets/komus_title4_05.png",
        "caption": "Проверьте успешное завершение"
      }
    ],
    "A104": [
      {
        "src": "assets/mass_before.png",
        "caption": "Откройте массовую обработку ЭТрН"
      },
      {
        "src": "assets/mass_success.png",
        "caption": "Дождитесь сообщения «Все документы обработаны»"
      }
    ],
    "A202": [
      {
        "src": "assets/komus_partner_qr_job.png",
        "caption": "Откройте нужную ЭТрН"
      },
      {
        "src": "assets/komus_partner_qr_share_1.png",
        "caption": "Откройте меню «Ссылка / Поделиться»"
      },
      {
        "src": "assets/komus_partner_qr_code.png",
        "caption": "Покажите QR-код для проверки"
      }
    ],
    "A105": [
      "assets/komus_not_loaded_job.png",
      "assets/komus_not_loaded_result.png"
    ],
    "A004": [
      "assets/reg_saby_store_01.png",
      "assets/reg_saby_store_02.png",
      "assets/reg_saby_icon.png",
      "assets/reg_saby_permission_01.png",
      "assets/reg_saby_permission_02.png",
      "assets/reg_saby_start.png",
      "assets/reg_saby_register_01.png",
      "assets/reg_saby_register_02.png",
      "assets/reg_saby_register_03.png",
      "assets/reg_saby_register_04.png",
      "assets/reg_saby_choose_ip_01.png",
      "assets/reg_saby_choose_ip_02.png",
      "assets/reg_saby_login_01.png",
      "assets/reg_saby_location.png"
    ],
    "A007": [
      "assets/reg_allow_goskey.png"
    ],
    "A009": [
      "assets/reg_kep_goskey_01.png",
      "assets/reg_kep_goskey_02.png",
      "assets/reg_kep_goskey_03.png",
      "assets/reg_kep_goskey_04.png",
      "assets/reg_kep_goskey_05.png",
      "assets/reg_kep_goskey_06.png",
      "assets/reg_kep_goskey_07.png",
      "assets/reg_kep_usb_01.png",
      "assets/reg_kep_usb_02.png",
      "assets/reg_kep_usb_03.png",
      "assets/reg_kep_usb_04.png",
      "assets/reg_kep_nfc_01.png",
      "assets/reg_kep_nfc_02.png",
      "assets/reg_kep_nfc_03.png",
      "assets/reg_kep_nfc_04.png"
    ],
    "A001": [
      "assets/reg_gosuslugi_01.png",
      "assets/reg_gosuslugi_02.png",
      "assets/reg_gosuslugi_03.png",
      "assets/reg_gosuslugi_04.png"
    ],
    "A002": [
      "assets/reg_goskey_profile.png",
      "assets/reg_goskey_install.png",
      "assets/reg_goskey_register.png"
    ],
    "A005": [
      "assets/reg_vehicle_menu.png",
      "assets/reg_vehicle_fields.png",
      "assets/reg_sts_fields.png"
    ],
    "A010": [
      "assets/reg_rutoken_usb.png",
      "assets/reg_download_os.png",
      "assets/reg_sytools_diag.png",
      "assets/reg_sytools_install.png",
      "assets/reg_sytools_store.png",
      "assets/reg_sytools_done.png",
      "assets/reg_saby_pc_download.png",
      "assets/reg_saby_pc_install.png",
      "assets/reg_saby_pc_allow.png",
      "assets/reg_saby_pc_setup.png",
      "assets/reg_saby_pc_icon.png",
      "assets/reg_saby_pc_login.png",
      "assets/reg_saby_personal_menu.png",
      "assets/reg_saby_personal_cabinet.png"
    ],
    "A008": [
      "assets/reg_subscription_01.png",
      "assets/reg_subscription_02.png",
      "assets/reg_subscription_03.png",
      "assets/reg_subscription_04.png"
    ],
    "A011": [
      {
        "src": "assets/reg_kep_usb_01.png",
        "caption": "Рутокен ЭЦП 3.0 для мобильного подключения"
      },
      {
        "src": "assets/reg_kep_usb_02.png",
        "caption": "Подключите Рутокен через подходящий переходник"
      },
      {
        "src": "assets/reg_kep_usb_04.png",
        "caption": "Проверьте УКЭП ИП в Saby TMS"
      }
    ]
  },
  "problems": {
    "P005": [
      "assets/komus_flc_file_error.png"
    ],
    "P007": [
      "assets/wrong_operator.jpg"
    ],
    "P008": [
      "assets/komus_other_operator_error.png"
    ],
    "P009": [
      "assets/ezz_required_fields_current.png"
    ],
    "P010": [
      "assets/komus_no_cert_error.png",
      "assets/komus_add_goskey_signatures.png",
      "assets/komus_goskey_certificate_flow.png"
    ],
    "P012": [
      "assets/participant_not_found.jpg"
    ],
    "P030": [
      "assets/goskey_kep_ip.jpg"
    ],
    "P039": [
      "assets/sytools_required.png"
    ],
    "P015": [
      "assets/mass_before.png",
      "assets/mass_success.png"
    ],
    "P041": [
      "assets/komus_not_loaded_job.png",
      "assets/komus_not_loaded_result.png"
    ],
    "P011": [
      "assets/komus_signature_wrong.png",
      "assets/komus_signature_correct.png"
    ],
    "P014": [
      "assets/komus_not_all_processed_dialog.png",
      "assets/komus_not_all_processed_job.png"
    ],
    "P040": [
      "assets/komus_no_jobs.png",
      "assets/komus_edo_company.png",
      "assets/komus_edo_documents.png"
    ],
    "P013": [
      "assets/komus_shutter_wait.png",
      "assets/komus_shutter_success.png"
    ],
    "P025": [
      "assets/komus_not_loaded_job.png",
      "assets/komus_not_loaded_result.png"
    ],
    "P045": [
      "assets/komus_partner_qr_doc.png",
      "assets/komus_partner_qr_job.png",
      "assets/komus_partner_qr_share_1.png",
      "assets/komus_partner_qr_share_2.png",
      "assets/komus_partner_qr_code.png"
    ],
    "P026": [
      "assets/reg_already_registered.png",
      "assets/reg_saby_support.png"
    ],
    "P027": [
      "assets/reg_saby_support.png"
    ]
  },
  "problem_errors": {
    "P005": [
      {
        "src": "assets/komus_flc_file_error.png",
        "caption": "Как выглядит проблема"
      }
    ],
    "P007": [
      {
        "src": "assets/wrong_operator.jpg",
        "caption": "Как выглядит проблема"
      }
    ],
    "P008": [
      {
        "src": "assets/komus_other_operator_error.png",
        "caption": "Как выглядит проблема"
      }
    ],
    "P009": [
      {
        "src": "assets/ezz_required_fields_current.png",
        "caption": "Saby просит заполнить финансовые поля заявки"
      }
    ],
    "P010": [
      {
        "src": "assets/komus_no_cert_error.png",
        "caption": "Как выглядит проблема"
      }
    ],
    "P012": [
      {
        "src": "assets/participant_not_found.jpg",
        "caption": "Как выглядит проблема"
      }
    ],
    "P039": [
      {
        "src": "assets/sytools_required.png",
        "caption": "Как выглядит проблема"
      }
    ],
    "P011": [
      {
        "src": "assets/komus_signature_wrong.png",
        "caption": "Как выглядит проблема"
      }
    ],
    "P014": [
      {
        "src": "assets/komus_not_all_processed_dialog.png",
        "caption": "Как выглядит проблема"
      }
    ],
    "P040": [
      {
        "src": "assets/komus_no_jobs.png",
        "caption": "Как выглядит проблема"
      }
    ],
    "P026": [
      {
        "src": "assets/reg_already_registered.png",
        "caption": "Как выглядит проблема"
      }
    ]
  },
  "problem_solutions": {
    "P010": [
      {
        "src": "assets/komus_add_goskey_signatures.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/komus_goskey_certificate_flow.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P030": [
      {
        "src": "assets/goskey_kep_ip.jpg",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P015": [
      {
        "src": "assets/mass_before.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/mass_success.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P041": [
      {
        "src": "assets/komus_not_loaded_job.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/komus_not_loaded_result.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P011": [
      {
        "src": "assets/komus_signature_correct.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P014": [
      {
        "src": "assets/komus_not_all_processed_job.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P040": [
      {
        "src": "assets/komus_edo_company.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/komus_edo_documents.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P013": [
      {
        "src": "assets/komus_shutter_wait.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/komus_shutter_success.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P025": [
      {
        "src": "assets/komus_not_loaded_job.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/komus_not_loaded_result.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P045": [
      {
        "src": "assets/komus_partner_qr_doc.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/komus_partner_qr_job.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/komus_partner_qr_share_1.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/komus_partner_qr_share_2.png",
        "caption": "Как исправить / что проверить"
      },
      {
        "src": "assets/komus_partner_qr_code.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P026": [
      {
        "src": "assets/reg_saby_support.png",
        "caption": "Как исправить / что проверить"
      }
    ],
    "P027": [
      {
        "src": "assets/reg_saby_support.png",
        "caption": "Как исправить / что проверить"
      }
    ]
  }
};