
const D=window.ETRN_DATA, V=window.ETRN_VISUALS||{actions:{},problems:{}};
const app=document.getElementById('app'); function statusClass(s){if(s==='Готово')return'ok';if(s==='Резервный порядок')return'reserve';return'none'} function unresolvedStatusBadge(status){ const s=(status||'').toLowerCase(); const unresolved = s.includes('нет решения') || s.includes('не решено') || s.includes('требует регламента') || s.includes('требует уточнения'); return unresolved ? `<span class="status none">Не решено</span>` : '';
} function header(){return `<div class="topbar">
      <div class="product-brand-clean">
        <strong>База помощи при работе с ЭТрН</strong>
        <small>Перевозчик ИП</small>
      </div>
      <button class="icon-btn" onclick="goSearch()" aria-label="Поиск">⌕</button>
    </div>`}
function bottom(active){return `<div class="bottom"><div class="bottom-inner">
      <button class="navbtn ${active==='route'?'active':''}" onclick="goHome()">Маршрут</button>
      <button class="navbtn ${active==='problem'?'active':''}" onclick="goProblems()">Проблема</button>
      <button class="navbtn ${active==='search'?'active':''}" onclick="goSearch()">Поиск</button>
    </div></div>`}
function modal(){return `<div id="imgmodal" class="modal" onclick="closeImage()"><button class="modal-close">×</button><img id="modalimg" alt=""></div>`}
function openImage(src){document.getElementById('modalimg').src=src;document.getElementById('imgmodal').classList.add('open')}
function closeImage(){document.getElementById('imgmodal')?.classList.remove('open')} function shots(paths,caption='Скриншот из действующей инструкции'){ if(!paths||!paths.length)return''; return `<div class="shots">${ paths.map((src,i)=>{ const official = /^https?:\/\/(link\.saby\.ru|online\.saby\.ru|saby\.ru|cdn2\.saby\.ru)/.test(src); const cap = official ? 'Справочный скрин из Saby' : caption; return `<div class="shot" onclick="openImage('${src}')"> <img src="${src}" loading="lazy" decoding="async" alt="${cap}" onerror="this.closest('.shot').classList.add('img-failed')"> <div class="shot-cap">${cap}${paths.length>1?' '+(i+1):''}</div> ${official?`<div class="shot-source">Источник: справочник Saby</div>`:''} </div>`; }).join('') }</div>`;
} function stageCards(){ return `<div class="home-route-line">${ D.stages.map((s,i)=>` <div class="home-route-item"> <button class="stage-card stage-card-linear" onclick="openStage('${s.id}')"> <div class="stage-no">${s.order}</div> <div class="stage-copy"> <h3>${s.button}</h3> <div class="muted">${s.goal}</div> </div> </button> ${i<D.stages.length-1?`<div class="route-connector">›</div>`:''} </div>`).join('') }</div>`;
} 
function feedbackNote(){
  return `<div class="site-feedback">
    <div class="site-feedback-title">Нашли неточность или неработающую инструкцию?</div>
    <div class="site-feedback-text">
      Сделайте скриншот, коротко опишите, что именно не работает или что нужно исправить, и отправьте сообщение в MAX.
    </div>
    <a class="site-feedback-link"
       href="https://max.ru/u/f9LHodD0cOKS-XbEvHfvAfQri7Hu54qHtMJ7TyramkR4zTZJ-j5Dj-EVnYQ"
       target="_blank" rel="noopener">Сообщить о неточности в MAX</a>
  </div>`;
}

function home(){ app.innerHTML=`<div class="shell">${header()}<main class="home-main"> <div class="section-title home-title"><h1>Маршрут работы</h1></div> ${stageCards()} <div class="version-note">Материалы актуализированы: 25.09.2026</div> ${feedbackNote()}</main>${bottom('route')}${modal()}</div>`
} function routePills(active){ return `<div class="route">${D.stages.map(s=>` <button class="route-pill ${s.id===active?'active':''}" onclick="openStage('${s.id}')"> <span class="route-pill-no">${s.order}</span><span>${s.button}</span> </button>`).join('')}</div>`;
} function problemCard(p, withThumb=false){ return `<div class="problem-card" onclick="openProblem('${p.id}')"> <h3>${p.title}</h3> <div class="muted" style="margin-top:6px">${p.symptom}</div> ${withThumb && V.problems[p.id]?.[0]?`<div class="thumb"><img src="${V.problems[p.id][0]}" loading="lazy" decoding="async" alt=""></div>`:''} ${referenceNote(p)} ${unresolvedStatusBadge(p.status)} </div>`
} function problemCards(stage,action=null,withThumb=false){ let list=D.problems[stage]||[]; if(action)list=list.filter(p=>p.action===action); if(!list.length)return`<div class="empty">Для этого шага отдельные проблемы пока не зафиксированы.</div>`; return list.map(p=>problemCard(p,withThumb)).join('')
} function formatInstruction(text){ return String(text||'').replace(/\n/g,'<br>');
} function referenceLinks(items){ if(!items||!items.length) return ''; const R=D.official_reference||{}; const links=items.map(item=>{ if(item.url){ return `<a class="reference-link" href="${item.url}" target="_blank" rel="noopener">${item.label||'Открыть источник'}</a>`; } const ref=R[item.ref]; if(!ref) return ''; return `<a class="reference-link" href="${ref.url}" target="_blank" rel="noopener">${item.label||ref.title}</a>`; }).filter(Boolean).join(''); return links?`<div class="reference-links">${links}</div>`:'';
} function referenceNote(p){ if(!p.reference_note) return ''; return `<div class="reference-note"><b>Справочно</b><br>${p.reference_note}${referenceLinks(p.links)}</div>`;
} function semanticShots(items, fallback='Экран из инструкции'){
  if(!items||!items.length) return '';
  const normalized=items.map(x=>typeof x==='string'?{src:x,caption:fallback}:x);
  return `<div class="shots">${normalized.map(item=>{
    const src=item.src;
    const cap=item.caption||fallback;
    const official=/^https?:\/\//.test(src);
    return `<div class="shot" onclick="openImage('${src}')">
      <img src="${src}" loading="lazy" decoding="async" alt="${cap}" onerror="this.closest('.shot').classList.add('img-failed')">
      <div class="shot-cap">${cap}</div>
      ${official?`<div class="shot-source">Источник: справочник Saby</div>`:''}
    </div>`;
  }).join('')}</div>`;
}

function substepsHtml(a){
  if(!a.substeps||!a.substeps.length) return '';
  return `<div class="learning-substeps">${a.substeps.map((s,i)=>{
    const visuals=(s.visuals||[]).map((src,j)=>({src,caption:(s.captions||[])[j]||s.title}));
    return `<div class="learning-substep">
      <button class="learning-substep-head" onclick="togglePanel('sub-${a.id}-${i}')">
        <span>${s.title}</span><span>⌄</span>
      </button>
      <div id="sub-${a.id}-${i}" class="inline-panel">
        <p>${s.text||''}</p>
        ${semanticShots(visuals,s.title)}
      </div>
    </div>`;
  }).join('')}</div>`;
}

function exceptionActionCard(a,id){
  const pcount=(D.problems[id]||[]).filter(p=>p.action===a.id).length;
  const vcount=(V.actions[a.id]||[]).length;
  return `<div class="exception-card" id="${a.id}">
    <button class="exception-head" onclick="toggleException('${a.id}')">
      <div><div class="exception-kicker">${a.exception_label||'Если возникла особая ситуация'}</div><h3>${a.title}</h3></div>
      <span>⌄</span>
    </button>
    <div class="exception-body">
      <div class="label">${a.instruction_label||'Что делать'}</div>
      <p class="instruction-text">${formatInstruction(a.instruction)}</p>
      ${referenceLinks(a.links)}
      ${vcount?`<button class="visual-toggle" onclick="event.stopPropagation();togglePanel('visual-${a.id}')"><span>Показать экраны</span><span>${vcount}</span></button>
      <div id="visual-${a.id}" class="inline-panel">${shots(V.actions[a.id],'Экран из инструкции')}</div>`:''}
      <div class="label">${a.result_label||'Проверьте результат'}</div>
      <div class="success">${a.success}</div>
      ${pcount?`<button class="problems-toggle" onclick="event.stopPropagation();togglePanel('problems-${a.id}')"><span>Если не получается</span><span>${pcount} ${problemWord(pcount)}</span></button>
      <div id="problems-${a.id}" class="inline-panel inline-problems">${problemCards(id,a.id,false)}</div>`:''}
    </div>
  </div>`;
}

function toggleException(id){
  document.getElementById(id)?.classList.toggle('open');
}

function actionCard(a,id){ const pcount=(D.problems[id]||[]).filter(p=>p.action===a.id).length; const vcount=(V.actions[a.id]||[]).length; return `<div class="action-card" id="${a.id}"> <div class="action-head" onclick="toggleAction('${a.id}')"> <div class="action-num">${a.order}</div> <div> ${a.mode?`<div class="action-mode">${a.mode}</div>`:''} <h3>${a.title}</h3> <div class="muted">${a.app}</div> </div> <div class="chev">⌄</div> </div> <div class="action-body"> <div class="label">${a.instruction_label||'Что нужно сделать'}</div> <p class="instruction-text">${formatInstruction(a.instruction)}</p> ${referenceLinks(a.links)} ${substepsHtml(a)} ${(!a.substeps&&vcount)?` <button class="visual-toggle" onclick="event.stopPropagation();togglePanel('visual-${a.id}')"> <span>Показать экран${vcount>1?'ы':''}</span><span>${vcount}</span> </button> <div id="visual-${a.id}" class="inline-panel">${shots(V.actions[a.id],'Экран из инструкции')}</div> `:''} <div class="label">${a.result_label||'Проверьте результат'}</div> <div class="success">${a.success}</div> ${pcount?` <button class="problems-toggle" onclick="event.stopPropagation();togglePanel('problems-${a.id}')"> <span>Если не получается</span><span>${pcount} ${problemWord(pcount)}</span> </button> <div id="problems-${a.id}" class="inline-panel inline-problems"> ${problemCards(id,a.id,false)} </div> `:''} </div> </div>`;
}  function renderActionsForStage(id,acts){
  const ordered=[...acts].sort((a,b)=>(a.order||0)-(b.order||0));
  const normal=ordered.filter(a=>!a.is_exception);
  const exceptions=ordered.filter(a=>a.is_exception);

  let normalHtml='';
  if(id==='S1'){
    normalHtml=normal.map(a=>actionCard(a,id)).join('');
  }else{
    normalHtml=normal.map(a=>actionCard(a,id)).join('');
  }

  const exceptionsHtml=exceptions.length?`
    <div class="exceptions-section">
      <div class="exceptions-title">Если ситуация отличается от обычной</div>
      ${exceptions.map(a=>exceptionActionCard(a,id)).join('')}
    </div>`:'';

  return normalHtml+exceptionsHtml;
} function titul2Rule(){ const r=D.titul2_rule; if(!r) return ''; return `<div class="timing-rule"> <div class="timing-main"> <div class="timing-kicker">Важно</div> <h3>${r.title}</h3> <p>${r.short}</p> <div class="timing-tags">${r.dont.map(x=>`<span>${x}</span>`).join('')}</div> <button class="timing-more" onclick="togglePanel('titul2-why')">Почему это важно?</button> <div id="titul2-why" class="inline-panel"><div class="timing-why">${r.why}</div></div> </div> </div>`;
} function registrationHelp(){ const h=(D.support||{}).registration; if(!h) return ''; return `<div class="registration-help"> <div class="registration-help-copy"> <div class="registration-help-kicker">Помощь с регистрацией</div> <h3>${h.name}</h3> <p>${h.send}</p> <a class="support-link" href="${h.url}" target="_blank" rel="noopener">Открыть группу в MAX</a> </div> <div class="registration-help-qr" onclick="openImage('assets/reg_help_max.png')"> <img src="assets/reg_help_max.png" alt="QR-код группы помощи с регистрацией"> <small>Нажмите, чтобы увеличить QR-код</small> </div> </div>`;
} function stagePage(id){ const s=D.stages.find(x=>x.id===id); const acts=D.actions[id]||[]; app.innerHTML=`<div class="shell">${header()}<main> <button class="back" onclick="goHome()">‹ На главную</button> ${routePills(id)} <section class="hero"> <div class="kicker">${s.location}</div> <h1>${s.title}</h1> <p>${s.goal}</p> <div class="success"><b>Этап завершён, когда:</b><br>${s.success}</div> </section> ${id==='S1'?titul2Rule():''} <div class="section-title"><h2>Что делать</h2></div> <div class="section-note">Открывайте только тот шаг, который выполняете сейчас.</div> ${renderActionsForStage(id,acts)} ${id==='S0'?registrationHelp():''} ${feedbackNote()}</main>${bottom('route')}${modal()}</div>`
} function problemWord(n){ const m10=n%10,m100=n%100; if(m10===1&&m100!==11)return'проблема'; if([2,3,4].includes(m10)&&![12,13,14].includes(m100))return'проблемы'; return'проблем';
} function allProblems(){return Object.values(D.problems).flat()} function groupProblemsByStage(){ return D.stages.map(s=>({ stage:s, items:(D.problems[s.id]||[]) })).filter(x=>x.items.length)
} function problemsPage(){ const groups=groupProblemsByStage(); app.innerHTML=`<div class="shell">${header()}<main> <h1>Что-то не получается</h1> <p class="muted">Сначала выберите, где вы находитесь. Показываем только проблемы выбранного этапа.</p> ${groups.map(g=>` <div class="compact-summary" onclick="togglePanel('group-${g.stage.id}')"> <div> <h3>${g.stage.title}</h3> <div class="muted">${g.stage.location}</div> </div> <div class="count">${g.items.length}</div> </div> <div id="group-${g.stage.id}" class="collapsible"> ${g.items.map(p=>problemCard(p,false)).join('')} </div> `).join('')} ${feedbackNote()}</main>${bottom('problem')}${modal()}</div>`
} function supportBlock(p){ const S=D.support||{}; let html=''; const text=(p.escalation||'').toLowerCase(); if(p.bot_only && S.bot){ html += `<div class="support-card"> <div class="support-title">${S.bot.name}</div> <div class="muted">${S.bot.platform} · ${S.bot.username}</div> <p>${S.bot.send}</p> <a class="support-link" href="${S.bot.url}" target="_blank" rel="noopener">Открыть бот «ЭТРН - ошибка»</a> <div class="support-safe">Не отправляйте: ${S.bot.never_send}.</div> </div>`; } if(text.includes('поддержка saby') && S.saby){ html += `<div class="support-card"> <div class="support-title">${S.saby.name}</div> <p>${S.saby.purpose}</p> <a class="support-link" href="${S.saby.url}" target="_blank" rel="noopener">Открыть поддержку Saby</a> </div>`; } if(text.includes('бухгалтер') && S.accountant){ html += `<div class="support-card"> <div class="support-title">${S.accountant.name}</div> <p>${S.accountant.purpose}</p> </div>`; } return html;
} function edoIdHelp(){ const S=D.support||{}; const text=S.dispatcher?.fns_id_help||'Идентификатор участника ЭДО: Saby → Настройки → Наши компании → своё ИП → Документы.'; return `<div class="specific-help"> <button class="mini-help-toggle" onclick="event.stopPropagation();this.nextElementSibling.classList.toggle('open')">Где найти идентификатор ЭДО?</button> <div class="mini-help-panel">${text}${referenceLinks([{label:'Справка Saby',ref:'edo_id'}])}</div> </div>`;
} function openProblem(id){ const p=allProblems().find(x=>x.id===id); const s=D.stages.find(x=>x.id===p.stage); const errorPics=(V.problem_errors||{})[p.id]||[]; const solutionPics=(V.problem_solutions||{})[p.id]||[]; app.innerHTML=`<div class="shell">${header()}<main> <button class="back" onclick="returnToAction('${p.stage}','${p.action||''}')">‹ Назад к шагу</button> <div class="problem-detail"> <div class="kicker">${s.title}</div> <div class="big">${p.title}</div> <div class="block"> <div class="label">Что вы видите</div> <p>${p.symptom}</p> ${errorPics.length?` <button class="visual-toggle" onclick="togglePanel('problem-error-visual')"> <span>Показать, как выглядит проблема</span><span>${errorPics.length}</span> </button> <div id="problem-error-visual" class="inline-panel">${shots(errorPics,'Пример проблемы')}</div> `:''} </div> <div class="block"> <div class="label">Почему это происходит</div> <p>${p.cause}</p> </div> <div class="block"> <div class="label">Что делать</div> <p>${p.solution}</p> ${solutionPics.length?` <button class="visual-toggle solution-visual-toggle" onclick="togglePanel('problem-solution-visual')"> <span>Показать, как сделать</span><span>${solutionPics.length}</span> </button> <div id="problem-solution-visual" class="inline-panel">${shots(solutionPics,'Как исправить / что проверить')}</div> `:''} ${referenceLinks(p.links)} ${p.reference_note?`<div class="reference-note"><b>Справочно</b><br>${p.reference_note}</div>`:''} ${p.show_edo_id_help?edoIdHelp():''} </div> ${p.escalation?` <div class="block"> <div class="label">Если не получилось</div> <p>${p.escalation}</p> ${supportBlock(p)} </div> `:''} ${unresolvedStatusBadge(p.status)?` <div class="notice"><b>Не решено.</b> Для этой ситуации пока нет подтверждённого полного рабочего решения. Используйте указанный безопасный порядок и эскалацию.</div> `:''} <button class="cta" onclick="returnToAction('${p.stage}','${p.action||''}')">Вернуться к шагу</button> </div> ${feedbackNote()}</main>${bottom('problem')}${modal()}</div>`
} function returnToAction(stageId,actionId){ location.hash=stageId; stagePage(stageId); if(!actionId) return; setTimeout(()=>{ if(['A103','A104'].includes(actionId)){ openChoiceAction(actionId); return; } const target=document.getElementById(actionId); if(target){ document.querySelectorAll('.action-card.open').forEach(el=>el.classList.remove('open')); target.classList.add('open'); target.scrollIntoView({behavior:'smooth',block:'start'}); } },80);
} function searchPage(){ app.innerHTML=`<div class="shell">${header()}<main> <h1>Поиск</h1> <p class="muted">Введи текст ошибки или несколько слов из ситуации.</p> <input id="q" class="searchbox" placeholder="Например: нет сертификата" oninput="runSearch(this.value)" autofocus> <div id="results" class="grid"></div> ${feedbackNote()}</main>${bottom('search')}${modal()}</div>`; runSearch('')
} function norm(s){
  return String(s||'').toLowerCase().replace(/ё/g,'е').replace(/[^a-zа-я0-9]+/gi,' ').trim();
}
function editDistance(a,b){
  if(Math.abs(a.length-b.length)>2) return 99;
  const dp=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=1;i<=a.length;i++){
    let prev=dp[0]; dp[0]=i;
    for(let j=1;j<=b.length;j++){
      const tmp=dp[j];
      dp[j]=Math.min(dp[j]+1,dp[j-1]+1,prev+(a[i-1]===b[j-1]?0:1));
      prev=tmp;
    }
  }
  return dp[b.length];
}
function searchScore(p,q){
  const nq=norm(q);
  if(!nq) return 0;
  const title=norm(p.title), symptom=norm(p.symptom), cause=norm(p.cause), solution=norm(p.solution);
  let score=0;
  if(title===nq) score+=120;
  else if(title.includes(nq)) score+=90;
  if(symptom.includes(nq)) score+=75;
  if(cause.includes(nq)) score+=35;
  if(solution.includes(nq)) score+=20;

  const alias=D.aliases.filter(a=>a.problem===p.id).map(a=>norm(a.q));
  if(alias.some(a=>a===nq)) score+=130;
  else if(alias.some(a=>a.includes(nq)||nq.includes(a))) score+=95;

  const qwords=nq.split(' ').filter(Boolean);
  const hay=[title,symptom,...alias].join(' ').split(' ').filter(Boolean);
  for(const qw of qwords){
    if(hay.some(w=>w===qw)) score+=10;
    else if(qw.length>=5 && hay.some(w=>w.length>=5 && editDistance(qw,w)<=1)) score+=6;
  }
  return score;
}
function runSearch(q){
  q=(q||'').trim();
  const box=document.getElementById('results');
  if(!box)return;
  if(!q){box.innerHTML=`<div class="empty">Начните вводить текст ошибки или проблему.</div>`;return}
  const ranked=allProblems()
    .map(p=>({p,score:searchScore(p,q)}))
    .filter(x=>x.score>0)
    .sort((a,b)=>b.score-a.score)
    .slice(0,12);
  box.innerHTML=ranked.length
    ?ranked.map(x=>problemCard(x.p,false)).join('')
    :`<div class="empty">Точного совпадения нет. Попробуйте сократить запрос до ключевых слов с экрана.</div>`;
} function toggleAction(id){
  const target=document.getElementById(id);
  if(!target) return;

  // Один обычный шаг открыт за раз.
  document.querySelectorAll('.action-card.open').forEach(el=>{
    if(el.id!==id) el.classList.remove('open');
  });

  target.classList.toggle('open');

  if(target.classList.contains('open')){
    setTimeout(()=>{
      target.scrollIntoView({behavior:'smooth',block:'start'});
    },80);
  }
}

function togglePanel(id){ const el=document.getElementById(id); if(!el)return; el.classList.toggle('open'); if(el.classList.contains('open')){ setTimeout(()=>el.scrollIntoView({behavior:'smooth',block:'nearest'}),60) }
} function openStage(id){location.hash=id;stagePage(id)}
function goHome(){location.hash='home';home()}
function goProblems(){location.hash='problems';problemsPage()}
function goSearch(){location.hash='search';searchPage()}
function render(){ const h=location.hash; if(h==='#problems')return problemsPage(); if(h==='#search')return searchPage(); if(/^#S\d/.test(h))return stagePage(h.slice(1)); home()
}
window.addEventListener('hashchange',render);
render();
